#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <cstring> // for strlen

using namespace std;

int main() 
{
    int pip[2];
    int pip1[2];
    char instring[100];
    pid_t pid;

    if (pipe(pip) == -1 || pipe(pip1) == -1) {
        cout << "Pipe error";
        return -1;
    }

    pid = fork();

    if (pid < 0) {
        cout << "Fork error";
        return -1;
    }

    if (pid == 0) { // Child process
        close(pip[1]);   // Close unused write end of the first pipe
        close(pip1[0]);  // Close unused read end of the second pipe

        while (true) {
            // Read from the pipe
            ssize_t bytesRead = read(pip[0], instring, sizeof(instring) - 1);

            instring[bytesRead] = '\0'; // Null-terminate the string

            if (string(instring) == "exit") {
                break; // Exit if "exit" is received
            }

            cout << "Child received: " << instring << endl;

            // Respond to parent
            cout << "Child: ";
            cin.getline(instring, sizeof(instring)); // Get response from child
            write(pip1[1], instring, strlen(instring));
        }

        close(pip[0]); // Close read
        close(pip1[1]); // Close write
    } 
    
    else { // Parent process
        close(pip[0]);   // Close read end 
        close(pip1[1]);  // Close write end 

        while (true) {
            cout << "Parent: ";
            cin.getline(instring, sizeof(instring)); // Get input from parent

            if (string(instring) == "exit") {
                write(pip[1], instring, strlen(instring)); // Inform child of exit
                break;
            }

            write(pip[1], instring, strlen(instring)); // Send message to child

            // Read response from child
            ssize_t bytesRead = read(pip1[0], instring, sizeof(instring) - 1);
            instring[bytesRead] = '\0';

            cout << "Parent received: " << instring << endl;
        }

        close(pip[1]); // Close write end 
        close(pip1[0]); // Close read end 
        wait(NULL); 
    }

    return 0;
}
