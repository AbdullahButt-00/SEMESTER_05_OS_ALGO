#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <cstring> // for strlen

using namespace std;

// Function to reverse a string
string reverse(const string& strval) {
    string newstr;
    for (int i = strval.size() - 1; i >= 0; i--) {
        newstr += strval[i];
    }
    return newstr;
}

int main() {
    int pip[2];   // Pipe for parent to child
    int pip1[2];  // Pipe for child to parent
    char instring[100];
    pid_t pid;

    if (pipe(pip) == -1 || pipe(pip1) == -1) {
        cout << "Pipe error";
        return -1;
    }

    pid = fork();

    if (pid < 0) {
        cout << "Fork error";
        return -1;
    }

    if (pid == 0) { // Child process
        close(pip[1]);   // Close unused write end of the first pipe
        close(pip1[0]);  // Close unused read end of the second pipe

        while (true) {
            // Read from the pipe
            ssize_t bytesRead = read(pip[0], instring, sizeof(instring) - 1);
            if (bytesRead <= 0) break; // Exit on read error or EOF
            instring[bytesRead] = '\0'; // Null-terminate the string

            if (string(instring) == "exit") {
                break; // Exit if "exit" is received
            }

            cout << "Child received: " << instring << endl;
            string reversest = reverse(string(instring));
            cout << "Reversing the string...." << endl;

            write(pip1[1], reversest.c_str(), reversest.size() + 1); // Send reversed string
        }

        close(pip[0]); // Close read end of pip
        close(pip1[1]); // Close write end of pip1
    } else { // Parent process
        close(pip[0]);   // Close read end of pip
        close(pip1[1]);  // Close write end of pip1

        while (true) {
            cout << "Parent: ";
            cin.getline(instring, sizeof(instring)); // Get input from parent

            if (string(instring) == "exit") {
                write(pip[1], instring, strlen(instring) + 1); // Inform child of exit
                break;
            }

            write(pip[1], instring, strlen(instring) + 1); // Send message to child

            // Read response from child
            ssize_t bytesRead = read(pip1[0], instring, sizeof(instring) - 1);
            if (bytesRead <= 0) break; // Exit on read error or EOF
            instring[bytesRead] = '\0'; // Null-terminate the string

            cout << "Parent received: " << instring << endl;
        }

        close(pip[1]); // Close write end of pip
        close(pip1[0]); // Close read end of pip1
        wait(NULL); // Wait for child process to finish
    }

    return 0;
}
