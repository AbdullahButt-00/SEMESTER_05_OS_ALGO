#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h> 
using namespace std;

int water = 0; 
sem_t lock;   


void *WaterFilter(void *arg) 
{
    //while (true) 
    for(int i=0; i<5; i++)
    {
        sem_wait(&lock); 

        water += 10; // 10L water
        cout<<"Added 10L water"<<endl;
        cout<<"Current water: "<<water<<" L" <<endl;

        sem_post(&lock); 
        sleep(1); // Simulate 1 second delay
        
        
        cout<<endl<<"____________________________________________________________________"<<endl;
    }

    pthread_exit(NULL);
    
    
}

void *Person(void *arg) 
{
    int person_id = *(int *)arg;
    
   // while (true) 
    for(int i=0; i<5; i++)
    {
        sem_wait(&lock); 

        if (water >= 5) 
        {   
            water -= 5; // Person takes 5L 
            cout << "Person "<< person_id << ": Took 5L of water"<<endl;
            cout<<"Remaining water: " << water<<"L"<<endl;
        } 
        
        else 
        { 
        cout << "Person " << person_id << ": Not enough water"<<endl;
        cout<<"Waiting..." << endl; 
        }

        sem_post(&lock); 
        sleep(1); 
        
      /// cout<<endl<<"____________________________________________________________________"<<endl;
    }

    pthread_exit(NULL);
}

int main() 
{

  // sem_init(&lock, 0, 1); // Binary semaphore
   sem_init(&lock, 0, 3); // Counting semaphore: up to 3 

    pthread_t filter_thread, person_threads[5];
    int person_ids[5] = {1, 2, 3, 4, 5}; 

    
    pthread_create(&filter_thread, NULL, WaterFilter, NULL);

   
    for (int i = 0; i < 5; i++) 
    {
        pthread_create(&person_threads[i], NULL, Person, &person_ids[i]);
    }

   pthread_join(filter_thread, NULL);
  
    for (int i = 0; i < 5; i++) 
    {
        pthread_join(person_threads[i], NULL);
    }

    sem_destroy(&lock); 
    return 0;
}



// Helping Code File for OS Lab Exam

// Semaphore Example - Counter
#include <iostream>
#include <pthread.h>
#include <semaphore.h>
using namespace std;

int count = 0;
sem_t lock1;

void* Counter(void*) {
    sem_wait(&lock1);
    count++;
    cout << "COUNTER: " << count << endl;
    sem_post(&lock1);
    pthread_exit(NULL);
}

int main() {
    sem_init(&lock1, 0, 0); // Binary semaphore locked initially

    pthread_t tid[5];
    for (int i = 0; i < 5; i++) {
        pthread_create(&tid[i], NULL, Counter, NULL);
    }

    cout << "Enter count: ";
    cin >> count;
    sem_post(&lock1);

    for (int i = 0; i < 5; i++) {
        pthread_join(tid[i], NULL);
    }

    sem_destroy(&lock1);
    return 0;
}

// Semaphore Example - Water Filter and Person Interaction
#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
using namespace std;

int water = 0;
sem_t lock;

void* WaterFilter(void* arg) {
    for (int i = 0; i < 5; i++) {
        sem_wait(&lock);
        water += 10;
        cout << "Added 10L water" << endl;
        cout << "Current water: " << water << " L" << endl;
        sem_post(&lock);
        sleep(1);
        cout << "____________________________________________________________________" << endl;
    }
    pthread_exit(NULL);
}

void* Person(void* arg) {
    int person_id = *(int*)arg;
    for (int i = 0; i < 5; i++) {
        sem_wait(&lock);
        if (water >= 5) {
            water -= 5;
            cout << "Person " << person_id << ": Took 5L of water" << endl;
            cout << "Remaining water: " << water << " L" << endl;
        } else {
            cout << "Person " << person_id << ": Not enough water" << endl;
            cout << "Waiting..." << endl;
        }
        sem_post(&lock);
        sleep(1);
    }
    pthread_exit(NULL);
}

int main() {
    sem_init(&lock, 0, 3); // Counting semaphore: allows up to 3 threads

    pthread_t filter_thread, person_threads[5];
    int person_ids[5] = {1, 2, 3, 4, 5};

    pthread_create(&filter_thread, NULL, WaterFilter, NULL);

    for (int i = 0; i < 5; i++) {
        pthread_create(&person_threads[i], NULL, Person, &person_ids[i]);
    }

    pthread_join(filter_thread, NULL);
    for (int i = 0; i < 5; i++) {
        pthread_join(person_threads[i], NULL);
    }

    sem_destroy(&lock);
    return 0;
}


