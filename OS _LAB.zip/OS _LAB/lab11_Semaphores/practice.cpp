#include <iostream>
#include <pthread.h>
#include <semaphore.h>
using namespace std;


int count=0;

sem_t lock1;

void *Counter(void *)
{   

sem_wait(&lock1); //check value if value>0, then decrement in it and lock the critical section
count++;
cout<<"COUNTER: "<<count<<endl;
sem_post(&lock1); // simply incremnt value of semaphore


pthread_exit(NULL);
}




int main() 
{

sem_init(&lock1, 0,0); // binary semaphore locked no thread in critical section

//sem_init(&lock1, 0,1); // binary semaphore

//sem_init(&lock1, 0,3); // counting semaphore

pthread_t tid[5];

for(int i=0;i<5;i++) 
{
pthread_create(&tid[i], NULL,Counter,NULL);
}

cout<<"Enter count"<<endl;
cin>>count;
sem_post(&lock1);


sem_destroy(&lock1);
pthread_exit(NULL);
return 0;

}



//print thread i for cars.

