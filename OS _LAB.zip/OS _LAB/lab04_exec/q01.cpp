
#include <iostream>
#include <unistd.h>
using namespace std;

int main ()
{

    execl ("./f", "file", "ABDULLAH", "BUTT", NULL);

   // execlp ("./f", "file", "ABDULLAH", "BUTT", NULL);
    
    char * arg [] = {"file", "ABDULLAH", "BUTT", NULL};
  //  execv ("./f", arg);
    
   // execvp ("./f", arg);
    
    char * en [] = {"PATH:/home/abdullah/Desktop/SEMESTER_5/OS _LAB/lab04_exec/f", NULL};
   // execle ("./f", "file", "ABDULLAH", "BUTT", NULL, en);
    
    execve ("./f", arg, en);
    
    
return 0;    
}
