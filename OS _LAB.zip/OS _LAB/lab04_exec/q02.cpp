#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <cstring>

using namespace std;

int main()
{
    string command;

    while (true)
    {
        cout << "Enter a command (pwd, ls, date, cal, cat) or 'Exit' to exit: ";
        getline(cin, command);

        if (command == "exit")
        {
            break; // Exit the loop if the user types "Exit"
        }

        pid_t childPid = fork();

        if (childPid < 0)
        {
            cerr << "Error: Unable to create child process" << endl;
            continue; // Skip to the next iteration on fork failure
        }
        else if (childPid == 0)
        {
            if (command == "pwd")
            {
                execlp("pwd", "pwd", nullptr);
            }
            else if (command == "ls")
            {
                execlp("ls", "ls", nullptr);
            }
            else if (command == "date")
            {
                execlp("date", "date", nullptr);
            }
            else if (command == "cal")
            {
                execlp("cal", "cal", nullptr);
            }
            else if (command.substr(0, 4) == "cat ")
            {
                // Directly using c_str() in execlp
                execlp("cat", "cat", command.substr(4).c_str(), nullptr);
            }
            else
            {
                cerr << "Invalid command" << endl; // Handle invalid input
                exit(1);
            }

            // If exec fails
            cerr << "Error: Command execution failed" << endl;
            exit(1);
        }
        else
        {
            // Parent process waits for the child to finish
            wait(nullptr);
        }
    }

    return 0;
}
