
#include <iostream>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <cstring>
#include <cstdlib>  //wait()
using namespace std;

int main()
{

string s1, s2;
cout<<"Input string 1: ";
getline(cin, s1);
cout<<"Input string 2: ";
getline(cin, s2);

pid_t pid;
int status;

// cout<<s1<<endl<<s2;

 // Create child process
pid = fork();

    if (pid < 0) {
        // Fork failed
        cerr << "Fork failed!" << endl;
        return 1;
    } 

    
	else if (pid == 0) 
	{
		

        // Child process
        if (s1 == s2) 
		{
            exit(1);  
        } 
		else 
		{
            exit(0);  
        }
    } 
    
	else 
	{
        
		wait(&status);
        int childStatus = WEXITSTATUS(status);


       	if (childStatus == 1) 
			{
                cout << "Strings are equal." << endl;
            } 
		else 
			{
                cout << "Strings are not equal." << endl;
            }
        
    }

    return 0;




}



