
#include <iostream>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <cstring>
#include <cstdlib>  //wait()
using namespace std;

int main()
{

int n1=4;
int n2=9;
cout<<"n1: "<<n1<<endl<<"n2: "<<n2<<endl;
pid_t pid;
int status;


pid = fork();

if (pid == 0) 
{
    if(n1>n2)
      {
        if(n1%2==0) {  cout<<"n1>n2 and even"<<endl;}
        
        else {  cout<<"n1>n2 and odd"<<endl;  }
        
      }

   else if(n1<n2)
   {
        if(n2%2==0) {  cout<<"n1<n2 and even"<<endl;}
        
        else {  cout<<"n1<n2 and odd"<<endl;  }
        


   }  	
        
    else 
	{
    if(n2%2==0) {  cout<<"both equal and even"<<endl;}
        
    else {  cout<<"both not equal and odd"<<endl;  }    
  
  
  }

exit(0);
}
  
else if(pid>0)
   {
    wait(&status);
   }


  
   return 0;




}



