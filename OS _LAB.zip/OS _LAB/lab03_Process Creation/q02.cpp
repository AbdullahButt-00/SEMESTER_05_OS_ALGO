
#include <iostream>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <cstring>
#include <cstdlib>  //wait()
using namespace std;

int main()
{

int a,b,c,d,e,f;
a = 4; b = 5; c = 20; d = 4; e = 10; f = 3;
pid_t pid;


pid = fork();

if (pid == 0) 
	{ exit(a*b);  }

else if(pid>0)
{
  int st1;
  int st2;
  int st3;

  wait(&st1);
  int x1=WEXITSTATUS(st1);
  cout<<"a*b= "<< WEXITSTATUS(st1)<<endl;

  pid_t pid2=fork();

  if (pid2 == 0)  { exit(c/d);  }

  else if(pid2>0)     
  {
    wait(&st2);

    int x2 =  WEXITSTATUS(st2);
    cout<<"c/d= "<< WEXITSTATUS(st2)<<endl;

     pid_t pid3=fork();

    if (pid3 == 0)  { exit(e-f);  }

    else if(pid3>0)
      {
          wait(&st3);

          int x3=WEXITSTATUS(st3);
          cout<<"e-f= "<< WEXITSTATUS(st3)<<endl;

          cout<<"RESULT: "<< x1 + x2 + x3;
      }


    }
}


return 0;
}



