#include <iostream>
#include <unistd.h>
#include <pthread.h>

using namespace std;

void* thread1(void* arg)
  
{  
   string *ptr=(string*)arg;
   cout<<"value a "<<*ptr<<endl;
   cout<<"a direct "<<*(string*)arg<<endl;

   cout<<"thread FUNCTION"<<endl;  
   cout<<"new thread id "<<pthread_self()<<endl;  
   pthread_exit(NULL);
   
}

int main() 
{

cout<<"*_*"<<endl;
cout<<"process id "<<getpid()<<endl;
cout<<"thread id "<<pthread_self()<<endl;


pthread_t tid;
string a;
cout<<"Enter input"<<endl;
cin>>a;

// pthread_create(thread id, thread attributes, thread func calling, arg passing )
pthread_create(&tid, NULL, thread1, (void*)&a );
cout<<"Current thread id: "<<tid<<endl;



pthread_exit(NULL);
return 0;
}



