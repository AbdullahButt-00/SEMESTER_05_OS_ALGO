//Q1: Process Creation (fork, exec) Basic Fork Example:

#include <iostream>
#include <sys/types.h>
#include <unistd.h>
using namespace std;

int main() {
    pid_t pid = fork();

    if (pid == 0) { // Child process
        cout << "Child Process (PID: " << getpid() << ")" << endl;
    } else if (pid > 0) { // Parent process
        cout << "Parent Process (PID: " << getpid() << ")" << endl;
    } else {
        cerr << "Fork failed!" << endl;
    }

    return 0;
}

//Fork with exec Example:

#include <iostream>
#include <unistd.h>
using namespace std;

int main() {
    pid_t pid = fork();

    if (pid == 0) { // Child process
        execlp("ls", "ls", nullptr); // Executes "ls" command
    } else if (pid > 0) {
        cout << "Parent Process waiting for child to finish..." << endl;
        wait(nullptr); // Parent waits for child to finish
    } else {
        cerr << "Fork failed!" << endl;
    }

    return 0;
}

//Q2: Inter-Process Communication (IPC) Using Pipes:
#include <iostream>
#include <unistd.h>
#include <cstring>
using namespace std;

int main() {
    int fd[2];
    pipe(fd); // Create a pipe
    pid_t pid = fork();

    if (pid == 0) { // Child process
        close(fd[0]); // Close unused read end
        string msg = "Hello from Child!";
        write(fd[1], msg.c_str(), msg.size() + 1); // Write to pipe
        close(fd[1]);
    } else if (pid > 0) { // Parent process
        close(fd[1]); // Close unused write end
        char buffer[100];
        read(fd[0], buffer, sizeof(buffer)); // Read from pipe
        cout << "Parent received: " << buffer << endl;
        close(fd[0]);
    }

    return 0;
}

//Q3: Threads Using POSIX Threads (pthreads):

#include <iostream>
#include <pthread.h>
using namespace std;

void* printMessage(void* arg) {
    cout << "Hello from Thread: " << (char*)arg << endl;
    return nullptr;
}

int main() {
    pthread_t thread;
    const char* message = "Thread 1";

    if (pthread_create(&thread, nullptr, printMessage, (void*)message)) {
        cerr << "Error creating thread" << endl;
        return 1;
    }

    pthread_join(thread, nullptr); // Wait for thread to finish
    cout << "Thread execution completed" << endl;

    return 0;
}

//Q4: Process Synchronization
//Using Mutex with Threads:

#include <iostream>
#include <pthread.h>
#include <unistd.h>
using namespace std;

pthread_mutex_t lock;

void* printCount(void* arg) {
    pthread_mutex_lock(&lock);
    for (int i = 0; i < 5; ++i) {
        cout << "Thread " << (char*)arg << " Count: " << i << endl;
        sleep(1);
    }
    pthread_mutex_unlock(&lock);
    return nullptr;
}

int main() {
    pthread_t t1, t2;
    const char* t1_name = "1";
    const char* t2_name = "2";

    pthread_mutex_init(&lock, nullptr);

    pthread_create(&t1, nullptr, printCount, (void*)t1_name);
    pthread_create(&t2, nullptr, printCount, (void*)t2_name);

    pthread_join(t1, nullptr);
    pthread_join(t2, nullptr);

    pthread_mutex_destroy(&lock);

    return 0;
}

// Producer-Consumer Problem:

#include <iostream>
#include <pthread.h>
#include <queue>
#include <unistd.h>
using namespace std;

queue<int> buffer;
const int BUFFER_SIZE = 5;
pthread_mutex_t lock;
pthread_cond_t notEmpty, notFull;

void* producer(void* arg) {
    for (int i = 1; i <= 10; ++i) {
        pthread_mutex_lock(&lock);

        while (buffer.size() == BUFFER_SIZE)
            pthread_cond_wait(&notFull, &lock);

        buffer.push(i);
        cout << "Produced: " << i << endl;

        pthread_cond_signal(&notEmpty);
        pthread_mutex_unlock(&lock);
        sleep(1);
    }
    return nullptr;
}

void* consumer(void* arg) {
    for (int i = 1; i <= 10; ++i) {
        pthread_mutex_lock(&lock);

        while (buffer.empty())
            pthread_cond_wait(&notEmpty, &lock);

        int item = buffer.front();
        buffer.pop();
        cout << "Consumed: " << item << endl;

        pthread_cond_signal(&notFull);
        pthread_mutex_unlock(&lock);
        sleep(1);
    }
    return nullptr;
}

int main() {
    pthread_t prod, cons;

    pthread_mutex_init(&lock, nullptr);
    pthread_cond_init(&notEmpty, nullptr);
    pthread_cond_init(&notFull, nullptr);

    pthread_create(&prod, nullptr, producer, nullptr);
    pthread_create(&cons, nullptr, consumer, nullptr);

    pthread_join(prod, nullptr);
    pthread_join(cons, nullptr);

    pthread_mutex_destroy(&lock);
    pthread_cond_destroy(&notEmpty);
    pthread_cond_destroy(&notFull);

    return 0;
}

// ===========================================================
// Process Creation (fork(), exec())
// ===========================================================
#include <iostream>
#include <sys/types.h>
#include <unistd.h>
using namespace std;

int main() {
    pid_t pid, pid1, pid2;

    pid = fork(); // Create a new process

    if (pid == 0) {
        cout << "--- Child 1 of Parent 1 ---" << endl;
        cout << "Process ID: " << pid << endl;

        pid2 = fork(); // Create another child process from child 1

        if (pid2 == 0) {
            cout << "--- Child 1 of Parent 2 (Child of Child 1 of Parent 1) ---" << endl;
        } else {
            cout << "Parent Process" << endl;
        }
    } else {
        cout << "Parent Process" << endl;
    }
    return 0;
}

// ===========================================================
// Process Creation with exit(), wait(), and fork()
// ===========================================================
#include <iostream>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <cstdlib> // For exit()
using namespace std;

int main() {
    int a = 4, b = 5, c = 20, d = 4, e = 10, f = 3;
    pid_t pid;

    pid = fork();

    if (pid == 0) {
        exit(a * b); // Child process exits with a * b
    } else if (pid > 0) {
        int status1, status2, status3;
        wait(&status1); // Wait for the first child
        int result1 = WEXITSTATUS(status1);
        cout << "a * b = " << result1 << endl;

        pid_t pid2 = fork();
        if (pid2 == 0) {
            exit(c / d); // Second child exits with c / d
        } else if (pid2 > 0) {
            wait(&status2);
            int result2 = WEXITSTATUS(status2);
            cout << "c / d = " << result2 << endl;

            pid_t pid3 = fork();
            if (pid3 == 0) {
                exit(e - f); // Third child exits with e - f
            } else if (pid3 > 0) {
                wait(&status3);
                int result3 = WEXITSTATUS(status3);
                cout << "e - f = " << result3 << endl;

                cout << "Final Result: " << result1 + result2 + result3 << endl;
            }
        }
    }

    return 0;
}

// ===========================================================
// Executing Commands with exec() Variants
// ===========================================================
#include <iostream>
#include <unistd.h>
using namespace std;

int main() {
    // Uncomment the desired exec function to test its behavior.

    // execl: Pass arguments directly
    // execl("./f", "file", "ABDULLAH", "BUTT", NULL);

    // execlp: Searches for the program in PATH
    // execlp("./f", "file", "ABDULLAH", "BUTT", NULL);

    // execv: Pass arguments as an array
    char *args[] = {"file", "ABDULLAH", "BUTT", NULL};
    // execv("./f", args);

    // execvp: Searches for the program in PATH
    // execvp("./f", args);

    // execle: Includes environment variables
    char *env[] = {"PATH:/home/abdullah/Desktop/SEMESTER_5/OS_LAB/lab04_exec/f", NULL};
    // execle("./f", "file", "ABDULLAH", "BUTT", NULL, env);

    // execve: Passes both arguments and environment variables
    execve("./f", args, env);

    return 0;
}

// ===========================================================
// Q2: Interactive Command Execution Using exec() Variants
// ===========================================================
#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <cstring>
using namespace std;

int main() {
    string command;

    while (true) {
        cout << "Enter a command (pwd, ls, date, cal, cat <filename>) or 'Exit' to quit: ";
        getline(cin, command);

        if (command == "Exit" || command == "exit") {
            break; // Exit the loop on "Exit"
        }

        pid_t childPid = fork();

        if (childPid < 0) {
            cerr << "Error: Unable to create child process" << endl;
            continue; // Retry on fork failure
        } else if (childPid == 0) { // Child process
            if (command == "pwd") {
                execlp("pwd", "pwd", NULL);
            } else if (command == "ls") {
                execlp("ls", "ls", NULL);
            } else if (command == "date") {
                execlp("date", "date", NULL);
            } else if (command == "cal") {
                execlp("cal", "cal", NULL);
            } else if (command.substr(0, 4) == "cat ") { // Handles "cat <filename>"
                execlp("cat", "cat", command.substr(4).c_str(), NULL);
            } else {
                cerr << "Invalid command" << endl;
                exit(1); // Exit with error code
            }

            cerr << "Error: Command execution failed" << endl;
            exit(1); // Exit on exec failure
        } else { // Parent process
            wait(NULL); // Wait for the child process
        }
    }

    return 0;
}

// ===========================================================
// Command-Line Arguments Example file.cpp
// ===========================================================
#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
    for (int i = 0; i < argc; i++) {
        cout << argv[i] << endl; // Print each command-line argument
    }
    return 0;
}




// Helping Code File for OS Lab Exam

// Unnamed Pipe - Interactive Communication Example
#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <cstring> // for strlen
using namespace std;

int main() {
    int pip[2];
    int pip1[2];
    char instring[100];
    pid_t pid;

    if (pipe(pip) == -1 || pipe(pip1) == -1) {
        cout << "Pipe error";
        return -1;
    }

    pid = fork();

    if (pid < 0) {
        cout << "Fork error";
        return -1;
    }

    if (pid == 0) { // Child process
        close(pip[1]);   // Close unused write end of the first pipe
        close(pip1[0]);  // Close unused read end of the second pipe

        while (true) {
            // Read from the pipe
            ssize_t bytesRead = read(pip[0], instring, sizeof(instring) - 1);
            if (bytesRead <= 0) break; // Exit on error or EOF
            instring[bytesRead] = '\0';

            if (string(instring) == "exit") break;

            cout << "Child received: " << instring << endl;
            cout << "Child: ";
            cin.getline(instring, sizeof(instring));
            write(pip1[1], instring, strlen(instring) + 1);
        }

        close(pip[0]);
        close(pip1[1]);
    } else { // Parent process
        close(pip[0]);   // Close read end
        close(pip1[1]);  // Close write end

        while (true) {
            cout << "Parent: ";
            cin.getline(instring, sizeof(instring));

            if (string(instring) == "exit") {
                write(pip[1], instring, strlen(instring) + 1);
                break;
            }

            write(pip[1], instring, strlen(instring) + 1);
            ssize_t bytesRead = read(pip1[0], instring, sizeof(instring) - 1);
            if (bytesRead <= 0) break;
            instring[bytesRead] = '\0';

            cout << "Parent received: " << instring << endl;
        }

        close(pip[1]);
        close(pip1[0]);
        wait(NULL);
    }

    return 0;
}

// Unnamed Pipe - String Reversal Example
#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <cstring> // for strlen
using namespace std;

string reverse(const string& str) {
    string reversed;
    for (int i = str.size() - 1; i >= 0; --i) {
        reversed += str[i];
    }
    return reversed;
}

int main() {
    int pip[2];
    int pip1[2];
    char instring[100];
    pid_t pid;

    if (pipe(pip) == -1 || pipe(pip1) == -1) {
        cout << "Pipe error";
        return -1;
    }

    pid = fork();

    if (pid < 0) {
        cout << "Fork error";
        return -1;
    }

    if (pid == 0) { // Child process
        close(pip[1]);
        close(pip1[0]);

        while (true) {
            ssize_t bytesRead = read(pip[0], instring, sizeof(instring) - 1);
            if (bytesRead <= 0) break;
            instring[bytesRead] = '\0';

            if (string(instring) == "exit") break;

            cout << "Child received: " << instring << endl;
            string reversed = reverse(string(instring));
            write(pip1[1], reversed.c_str(), reversed.size() + 1);
        }

        close(pip[0]);
        close(pip1[1]);
    } else { // Parent process
        close(pip[0]);
        close(pip1[1]);

        while (true) {
            cout << "Parent: ";
            cin.getline(instring, sizeof(instring));

            if (string(instring) == "exit") {
                write(pip[1], instring, strlen(instring) + 1);
                break;
            }

            write(pip[1], instring, strlen(instring) + 1);
            ssize_t bytesRead = read(pip1[0], instring, sizeof(instring) - 1);
            if (bytesRead <= 0) break;
            instring[bytesRead] = '\0';

            cout << "Parent received: " << instring << endl;
        }

        close(pip[1]);
        close(pip1[0]);
        wait(NULL);
    }

    return 0;
}

// Named Pipe Example - Input to Processing
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <cstring>
using namespace std;

int main() {
    mkfifo("pipe1", 0666);

    int fd = open("pipe1", O_WRONLY);
    if (fd == -1) {
        perror("open");
        exit(1);
    }

    char buf[100];
    cout << "Enter to write: ";
    cin.getline(buf, sizeof(buf));
    write(fd, buf, strlen(buf) + 1);
    close(fd);

    return 0;
}

// Named Pipe Example - Processing to Output
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <cstring>
#include <fstream>
#include <iostream>
using namespace std;

int main() {
    mkfifo("output_pipe", 0666);

    int fd_read = open("pipe1", O_RDONLY);
    if (fd_read == -1) {
        perror("open");
        return 1;
    }

    char buf[100];
    read(fd_read, buf, sizeof(buf));
    close(fd_read);

    int fd_write = open("output_pipe", O_WRONLY);
    if (fd_write == -1) {
        perror("open");
        return 1;
    }

    for (int i = 0; buf[i] != '\0'; ++i) {
        int ascii_value = static_cast<int>(buf[i]);
        write(fd_write, &ascii_value, sizeof(ascii_value));
    }

    int end_signal = -1;
    write(fd_write, &end_signal, sizeof(end_signal));
    close(fd_write);

    return 0;
}

// Named Pipe Example - Output to Console
#include <stdio.h>
#include <iostream>
#include <unistd.h>
#include <fcntl.h>
using namespace std;

int main() {
    int fd = open("output_pipe", O_RDONLY);
    if (fd == -1) {
        perror("open");
        return 1;
    }

    int ascii_value;
    cout << "ASCII values: ";
    while (true) {
        read(fd, &ascii_value, sizeof(ascii_value));
        if (ascii_value == -1) break;
        cout << ascii_value << " ";
    }
    cout << endl;

    close(fd);
    return 0;
}

// Helping Code File for OS Lab Exam

// Thread Example
#include <iostream>
#include <unistd.h>
#include <pthread.h>
using namespace std;

void* thread1(void* arg) {  
   string *ptr = (string*)arg;
   cout << "Value passed: " << *ptr << endl;
   cout << "Direct dereference: " << *(string*)arg << endl;
   cout << "Thread FUNCTION" << endl;  
   cout << "New thread ID: " << pthread_self() << endl;  
   pthread_exit(NULL);
}

int main() {
    cout << "Process ID: " << getpid() << endl;
    cout << "Main thread ID: " << pthread_self() << endl;

    pthread_t tid;
    string a;
    cout << "Enter input: ";
    cin >> a;

    pthread_create(&tid, NULL, thread1, (void*)&a);
    cout << "Created thread ID: " << tid << endl;

    pthread_exit(NULL);
    return 0;
}

// Mutex Example
#include <iostream>
#include <pthread.h>
using namespace std;

int count = 0, count_mod;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

void* thread1(void* arg) {
    pthread_mutex_lock(&mutex);
    count++;
    cout << "Thread 1: Count = " << count << endl;
    pthread_mutex_unlock(&mutex);

    count_mod = count % 2;
    cout << "Thread 1: Count % 2 = " << count_mod << endl;
    pthread_exit(NULL);
}

int main() {
    pthread_t tid;
    pthread_create(&tid, NULL, thread1, NULL);
    pthread_join(tid, NULL);
    pthread_mutex_destroy(&mutex);
    return 0;
}

// Multithreading Mutex and Synchronization Example
#include <iostream>
#include <pthread.h>
#include <unistd.h>
using namespace std;

int balance = 20;
pthread_mutex_t balance_mutex = PTHREAD_MUTEX_INITIALIZER;

void* deposit(void* tid) {
    int thread_id = *(int*)tid;
    for (int i = 0; i < 10; ++i) {
        pthread_mutex_lock(&balance_mutex);
        int readbalance = balance;
        cout << "At time " << i << ", balance before deposit by thread " << thread_id << " is $" << readbalance << endl;
        readbalance += 11;
        sleep(1);
        balance = readbalance;
        cout << "At time " << i << ", balance after deposit by thread " << thread_id << " is $" << balance << endl;
        pthread_mutex_unlock(&balance_mutex);
        sleep(10);
    }
    return nullptr;
}

void* withdraw(void* tid) {
    int thread_id = *(int*)tid;
    for (int i = 0; i < 10; ++i) {
        pthread_mutex_lock(&balance_mutex);
        while (balance < 10) {
            pthread_mutex_unlock(&balance_mutex);
            usleep(100000);
            pthread_mutex_lock(&balance_mutex);
        }
        int readbalance = balance;
        cout << "At time " << i << ", balance before withdrawal by thread " << thread_id << " is $" << readbalance << endl;
        readbalance -= 10;
        sleep(1);
        balance = readbalance;
        cout << "At time " << i << ", balance after withdrawal by thread " << thread_id << " is $" << balance << endl;
        pthread_mutex_unlock(&balance_mutex);
        sleep(1);
    }
    return nullptr;
}

int main() {
    pthread_t threads[4];
    int thread_ids[4] = {1, 2, 3, 4};

    pthread_create(&threads[0], nullptr, deposit, &thread_ids[0]);
    pthread_create(&threads[1], nullptr, deposit, &thread_ids[1]);
    pthread_create(&threads[2], nullptr, withdraw, &thread_ids[2]);
    pthread_create(&threads[3], nullptr, withdraw, &thread_ids[3]);

    for (int i = 0; i < 4; ++i) {
        pthread_join(threads[i], nullptr);
    }

    pthread_mutex_destroy(&balance_mutex);
    cout << "All threads finished execution." << endl;
    return 0;
}

// Mutex with Conditional Variable Example
#include <iostream>
#include <pthread.h>
#include <unistd.h>
using namespace std;

int fuel = 0;
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t fuelchk = PTHREAD_COND_INITIALIZER;

void* fuelstation(void* arg) {
    for (int i = 0; i < 5; i++) {
        pthread_mutex_lock(&lock);
        fuel += 60;
        cout << "Fuel filled: " << fuel << endl;
        pthread_mutex_unlock(&lock);
        pthread_cond_broadcast(&fuelchk);
        sleep(1);
    }
    pthread_exit(NULL);
}

void* car(void* arg) {
    pthread_mutex_lock(&lock);
    while (fuel < 40) {
        pthread_cond_wait(&fuelchk, &lock);
    }
    fuel -= 40;
    cout << "Got Fuel" << endl << "Car " << pthread_self() << endl;
    cout << "Remaining fuel: " << fuel << endl;
    cout << "---------------------------------------------------" << endl;
    pthread_mutex_unlock(&lock);
    pthread_exit(NULL);
}

int main() {
    pthread_t tid[4];
    pthread_create(&tid[0], NULL, fuelstation, NULL);
    pthread_create(&tid[1], NULL, car, NULL);
    pthread_create(&tid[2], NULL, car, NULL);
    pthread_create(&tid[3], NULL, car, NULL);

    for (int i = 0; i < 4; ++i) {
        pthread_join(tid[i], NULL);
    }

    pthread_mutex_destroy(&lock);
    pthread_cond_destroy(&fuelchk);
    return 0;
}

// Conditional Variable with Car and Boat Example
#include <iostream>
#include <pthread.h>
#include <unistd.h>
using namespace std;

pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t bridge_cond = PTHREAD_COND_INITIALIZER;

bool bridge_free = true;

void* car(void* arg) {
    int car_id = *(int*)arg;
    pthread_mutex_lock(&lock);
    while (!bridge_free) {
        pthread_cond_wait(&bridge_cond, &lock);
    }
    bridge_free = false;
    cout << "Car " << car_id << " passing:" << endl;
    for (int i = 0; i < 3; ++i) {
        cout << "*";
        sleep(1);
    }
    cout << endl;
    bridge_free = true;
    pthread_cond_signal(&bridge_cond);
    pthread_mutex_unlock(&lock);
    pthread_exit(NULL);
}

void* boat(void* arg) {
    int boat_id = *(int*)arg;
    pthread_mutex_lock(&lock);
    while (!bridge_free) {
        pthread_cond_wait(&bridge_cond, &lock);
    }
    bridge_free = false;
    cout << "Boat " << boat_id << " passing:" << endl;
    for (int i = 0; i < 5; ++i) {
        cout << "*";
        sleep(1);
    }
    cout << endl;
    bridge_free = true;
    pthread_cond_signal(&bridge_cond);
    pthread_mutex_unlock(&lock);
    pthread_exit(NULL);
}

int main() {
    int cars, boats;
    cout << "Enter the number of cars: ";
    cin >> cars;
    cout << "Enter the number of boats: ";
    cin >> boats;

    pthread_t car_threads[cars], boat_threads[boats];
    int car_ids[cars], boat_ids[boats];

    for (int i = 0; i < cars; ++i) {
        car_ids[i] = i + 1;
        pthread_create(&car_threads[i], NULL, car, &car_ids[i]);
    }

    for (int i = 0; i < boats; ++i) {
        boat_ids[i] = i + 1;
        pthread_create(&boat_threads[i], NULL, boat, &boat_ids[i]);
    }

    for (int i = 0; i < cars; ++i) {
        pthread_join(car_threads[i], NULL);
    }

    for (int i = 0; i < boats; ++i) {
        pthread_join(boat_threads[i], NULL);
    }

    pthread_mutex_destroy(&lock);
    pthread_cond_destroy(&bridge_cond);
    return 0;
}


// Helping Code File for OS Lab Exam

// Semaphore Example - Counter
#include <iostream>
#include <pthread.h>
#include <semaphore.h>
using namespace std;

int count = 0;
sem_t lock1;

void* Counter(void*) {
    sem_wait(&lock1);
    count++;
    cout << "COUNTER: " << count << endl;
    sem_post(&lock1);
    pthread_exit(NULL);
}

int main() {
    sem_init(&lock1, 0, 0); // Binary semaphore locked initially

    pthread_t tid[5];
    for (int i = 0; i < 5; i++) {
        pthread_create(&tid[i], NULL, Counter, NULL);
    }

    cout << "Enter count: ";
    cin >> count;
    sem_post(&lock1);

    for (int i = 0; i < 5; i++) {
        pthread_join(tid[i], NULL);
    }

    sem_destroy(&lock1);
    return 0;
}

// Semaphore Example - Water Filter and Person Interaction
#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
using namespace std;

int water = 0;
sem_t lock;

void* WaterFilter(void* arg) {
    for (int i = 0; i < 5; i++) {
        sem_wait(&lock);
        water += 10;
        cout << "Added 10L water" << endl;
        cout << "Current water: " << water << " L" << endl;
        sem_post(&lock);
        sleep(1);
        cout << "____________________________________________________________________" << endl;


    }
    pthread_exit(NULL);
}

void* Person(void* arg) {
    int person_id = *(int*)arg;
    for (int i = 0; i < 5; i++) {
        sem_wait(&lock);
        if (water >= 5) {
            water -= 5;
            cout << "Person " << person_id << ": Took 5L of water" << endl;
            cout << "Remaining water: " << water << " L" << endl;
        } else {
            cout << "Person " << person_id << ": Not enough water" << endl;
            cout << "Waiting..." << endl;
        }
        sem_post(&lock);
        sleep(1);
    }
    pthread_exit(NULL);
}

int main() {
    sem_init(&lock, 0, 3); // Counting semaphore: allows up to 3 threads

    pthread_t filter_thread, person_threads[5];
    int person_ids[5] = {1, 2, 3, 4, 5};

    pthread_create(&filter_thread, NULL, WaterFilter, NULL);

    for (int i = 0; i < 5; i++) {
        pthread_create(&person_threads[i], NULL, Person, &person_ids[i]);
    }

    pthread_join(filter_thread, NULL);
    for (int i = 0; i < 5; i++) {
        pthread_join(person_threads[i], NULL);
    }

    sem_destroy(&lock);
    return 0;
}


For Unnamed Pipes, Threads, Mutex, and Semaphore:

bash
Copy code
g++ -o program_name program_name.cpp -lpthread

For Named Pipes (FIFO): Named pipes require no additional libraries. Compile as:
bash
Copy code
g++ -o named_pipe_program named_pipe_program.cpp


g++ -o unnamed_pipe unnamed_pipe.cpp -lpthread


Named Pipes
Compile all parts (e.g., input, processing, and output files):

bash
Copy code
g++ -o input 1_input.cpp
g++ -o processing 2_processing.cpp
g++ -o output 3_output.cpp

g++ -o thread_program thread_program.cpp -lpthread

g++ -o mutex_program mutex_program.cpp -lpthread

g++ -o semaphore_program semaphore_program.cpp -lpthread


