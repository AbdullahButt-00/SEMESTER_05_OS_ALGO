#include <iostream>
#include <sys/types.h>
#include <unistd.h>
using namespace std;

int main()
{

pid_t pid;
pid_t pid1;
pid_t pid2;
pid_t pid3;

pid= fork();

if( pid==0)
{
	 cout<<"C-1 of P-1"<<endl;
	 cout<<"P ID:"<<pid<<endl;
}	 
	 
	 
	 
	 
else
 { 
	   if(pid>0)
	    {
	    pid2=fork();
	    cout<<"~~P-1~~"<<endl;
	    cout<<"P ID: "<<getpid<<endl;
	    }
	    if(pid2==0)
	    {
	    cout<<"~~ C-2 of P-1 ~~"<<endl;
	    }
	else
	{
	    if(pid2>0)
	    { 
	    pid3=fork();
	    if(pid3==0)
	    { cout<<"~~ C-3 of P-1 ~~"<<endl; }
	    }
	}

 }
	 

}



