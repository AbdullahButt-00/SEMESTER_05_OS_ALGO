#include <iostream>
#include <sys/types.h>
#include <unistd.h>
using namespace std;

int main()
{

pid_t pid;
pid_t pid1;
pid_t pid2;


pid= fork();

if( pid==0)
{
	 cout<<"--- C-1 of P-1 ---"<<endl;
	 cout<<"P ID:"<<pid<<endl;
	 
	 pid2=fork();
	 
	   
	 if( pid2==0)
       {
       cout<<"--- C-1 of P-2 which is c-1 of p-1 ---"<<endl;
       }
       
       else
       {  cout<<"p"<<endl;  }
       
 }          
	 
       
       
 else
  {
  cout<<"P"<<endl;
  }
       	 
	 
}	 
	 
	 



