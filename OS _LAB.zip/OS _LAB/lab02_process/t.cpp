#include <iostream>
#include <sys/types.h>
#include <unistd.h>
using namespace std;

int main()
{

pid_t pid=fork();
pid_t pid1=fork();
pid_t pid2=fork();
pid_t pid3=fork();

if(pid==0) { cout<<"hello"<<endl;}
else {cout<<"1"<<endl;}
 

return 0;

}



