#include <iostream>
#include <pthread.h>
#include <unistd.h>
using namespace std;


int fuel=0;

pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t fuelchk = PTHREAD_COND_INITIALIZER; 

void *fuelstation(void *arg)
 {   sleep(1);

    for(int i=0; i<5;i++) 
    { 
        pthread_mutex_lock(&lock);   

        fuel+=60;
        cout<<"Fuel filled: "<<fuel<<endl;
        pthread_mutex_unlock(&lock);
        pthread_cond_signal(&fuelchk);

        // pthread_cond_broadcast(&fuelchk);



    } sleep(1);

    pthread_exit(NULL);
}


void *car(void *arg)
{   

    pthread_mutex_lock(&lock);   
    while(fuel<40)
    {
    pthread_cond_wait(&fuelchk, &lock);
    }


        fuel-=40;
        cout<<"Got Fuel"<<endl;
        pthread_mutex_unlock(&lock);

        pthread_exit(NULL);
}



int main() 
{
    pthread_t tid[4];
    
    pthread_create(&tid[0],NULL,fuelstation,NULL);
         
    pthread_create(&tid[1],NULL,car,NULL);
    pthread_create(&tid[2],NULL,car,NULL);
    pthread_create(&tid[3],NULL,car,NULL);


pthread_exit(NULL);
return 0;

}
