#include <iostream>
#include <pthread.h>
using namespace std;

// Global shared variable and mutex
int count = 0, count_mod;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER; // Static initialization

void *thread1(void *arg)
 {
    // Start critical section 1: Lock mutex to protect shared variable
    pthread_mutex_lock(&mutex);
    
    count++; // Increment the shared variable
    
    // Print count inside critical section
    cout << "Thread 1: Count = " << count << endl;
    
    // End critical section 1: Unlock mutex
    pthread_mutex_unlock(&mutex);
    
    // Start critical section 2: Compute modulo outside the lock
    count_mod = count % 2;
    
    // Print count modulo result
    cout << "Thread 1: Count % 2 = " << count_mod << endl;
    
    pthread_exit(NULL);
}

int main() {
    pthread_t tid; // Thread ID

    // Create a new thread
    pthread_create(&tid, NULL, thread1, NULL);

    // Wait for the thread to finish
    pthread_join(tid, NULL);

    // Destroy the mutex (clean up)
    pthread_mutex_destroy(&mutex);

    // Exit the main thread
    return 0;
}
