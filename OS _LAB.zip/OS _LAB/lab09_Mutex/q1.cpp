#include <iostream>
#include <pthread.h>
#include <unistd.h>
using namespace std;


int balance = 20;
pthread_mutex_t balance_mutex = PTHREAD_MUTEX_INITIALIZER;

void* deposit(void* tid) 
{
    int thread_id = *(int*)tid;
    for (int i = 0; i < 10; ++i) 
    {
        pthread_mutex_lock(&balance_mutex);

        int readbalance = balance;
        cout << "At time " << i << ", the balance before depositing by thread " << thread_id << " is $" << readbalance << endl;
        readbalance += 11;
        sleep(1);  
        balance = readbalance;
        cout << "At time " << i << ", the balance after depositing by thread " << thread_id << " is $" << balance << endl;

        pthread_mutex_unlock(&balance_mutex);
        sleep(10);  
    }
    return nullptr;
}

void* withdraw(void* tid) {
    int thread_id = *(int*)tid;
    for (int i = 0; i < 10; ++i) {
        pthread_mutex_lock(&balance_mutex);

        
        while (balance < 10) {
            pthread_mutex_unlock(&balance_mutex);
            usleep(100000);  
            pthread_mutex_lock(&balance_mutex);
        }

        int readbalance = balance;
        cout << "At time " << i << ", the balance before withdrawing by thread " << thread_id << " is $" << readbalance << endl;
        readbalance -= 10;
        sleep(1);  
        balance = readbalance;
        cout << "At time " << i << ", the balance after withdrawing by thread " << thread_id << " is $" << balance << endl;

        pthread_mutex_unlock(&balance_mutex);
        sleep(1);  
    }
    return nullptr;
}

int main() {
    pthread_t threads[4];
    int thread_ids[4] = {1, 2, 3, 4};

    pthread_create(&threads[0], nullptr, deposit, &thread_ids[0]);
    pthread_create(&threads[1], nullptr, deposit, &thread_ids[1]);

  
    pthread_create(&threads[2], nullptr, withdraw, &thread_ids[2]);
    pthread_create(&threads[3], nullptr, withdraw, &thread_ids[3]);

  
    for (int i = 0; i < 4; ++i) {
        pthread_join(threads[i], nullptr);
    }

    pthread_mutex_destroy(&balance_mutex);  // Clean up the mutex

    cout << "All threads finished execution." << endl;
    return 0;
}

