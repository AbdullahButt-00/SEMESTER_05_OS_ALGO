#include <iostream>
#include <pthread.h>
#include <unistd.h>
using namespace std;


pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t bridge_cond = PTHREAD_COND_INITIALIZER;

bool bridge_free = true; 


int cars, car_time, boats, boat_time;



void* car(void* arg) 
{
    int car_id = *((int*)arg); 

    pthread_mutex_lock(&lock);

    while (!bridge_free) 
    {
        pthread_cond_wait(&bridge_cond, &lock);
    }

    bridge_free = false;

    cout << "Car " << car_id << " passing:"<<endl;
    for (int i = 0; i < car_time; ++i) 
    {
        cout << "*";
        sleep(1);
    }
    cout << endl;

    bridge_free = true;
    pthread_cond_signal(&bridge_cond);
    pthread_mutex_unlock(&lock);

    pthread_exit(NULL);
}



void* boat(void* arg) 
{
    int boat_id = *((int*)arg); 

    pthread_mutex_lock(&lock);

   
    while (!bridge_free) 
    {
        pthread_cond_wait(&bridge_cond, &lock);
    }

    bridge_free = false;

    
    cout << "Boat " << boat_id << " passing:"<<endl;
    for (int i = 0; i < boat_time; ++i) 
    {
        cout << "*";
        sleep(1);
    }
    cout << endl<<endl;

    bridge_free = true;
   
    pthread_cond_signal(&bridge_cond);
    pthread_mutex_unlock(&lock);

    pthread_exit(NULL);
}

int main() 
{
    cout << "Enter the no.of cars and car time: ";
    cin >> cars >> car_time;

    cout << "Enter the no.of boats and boat stime: ";
    cin >> boats >> boat_time;

    pthread_t car_threads[cars];
    pthread_t boat_threads[boats];

    int car_ids[cars], boat_ids[boats];

    for (int i = 0; i < cars; ++i) 
    {
        car_ids[i] = i + 1;
        pthread_create(&car_threads[i], NULL, car, &car_ids[i]);
    }


    for (int i = 0; i < boats; ++i) 
    {
        boat_ids[i] = i + 1;
        pthread_create(&boat_threads[i], NULL, boat, &boat_ids[i]);
    }


  

    for (int i = 0; i < cars; ++i) 
    { pthread_join(car_threads[i], NULL); }

    for (int i = 0; i < boats; ++i) 
    { pthread_join(boat_threads[i], NULL); }



    pthread_exit(NULL);

    return 0;
}
