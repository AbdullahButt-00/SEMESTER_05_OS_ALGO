#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <fstream>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <cstring>
#include <fcntl.h>

using namespace std;

int main() {
    // Open the second pipe for reading
    int fd = open("output_pipe", O_RDONLY);
    if (fd == -1) {
        perror("open");
        return 1;
    }

    int ascii_value;
    cout << "ASCII values: ";
    while (true) {
        read(fd, &ascii_value, sizeof(ascii_value));
        if (ascii_value == -1) {
            break; // Exit if sentinel value is received
        }
        cout << ascii_value << " ";
    }
    cout << endl;

    close(fd);
    return 0;
}
