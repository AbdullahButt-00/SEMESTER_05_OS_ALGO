#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <cstring>

using namespace std;


int main() 
{


mkfifo("pipe1",0666);



int fd= open("pipe1", O_WRONLY);
 if (fd == -1) {
        perror("open");
        exit(1);
    }
char buf[100];
cout<<"Enter to write "<<endl;
cin.getline(buf, sizeof(buf) );


write(fd,buf,strlen(buf)+1);
close(fd);

    
    


return 0;
}



