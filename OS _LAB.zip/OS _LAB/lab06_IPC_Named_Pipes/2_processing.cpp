#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <cstring>
#include <fstream>
#include <sys/stat.h>
#include<iostream>

using namespace std;




int main() {

    mkfifo("output_pipe", 0666);

    // Open the first pipe for reading
    int fd_read = open("pipe1", O_RDONLY);
    if (fd_read == -1) {
        perror("open");
        return 1;
    }

    char buf[100];
    read(fd_read, buf, sizeof(buf));
    close(fd_read);

    // Open the second pipe for writing
    int fd_write = open("output_pipe", O_WRONLY);
    if (fd_write == -1) {
        perror("open");
        return 1;
    }

    // Convert the string to ASCII values and send them through the second pipe
    for (int i = 0; buf[i] != '\0'; ++i) {
        int ascii_value = static_cast<int>(buf[i]);
        write(fd_write, &ascii_value, sizeof(ascii_value)); // Write each ASCII value
    }

    // Send a terminating value to indicate the end
    int end_signal = -1; // Using -1 as a sentinel value
    write(fd_write, &end_signal, sizeof(end_signal));
    close(fd_write);

    return 0;
}


