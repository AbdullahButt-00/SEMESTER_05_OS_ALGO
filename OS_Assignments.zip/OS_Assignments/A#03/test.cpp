#include <iostream>
#include <unistd.h>
#include <iomanip>
#include <pthread.h>

#include <cstdlib>
#include <ctime>
#include <queue>
#include <cstring>

using namespace std;

bool flag = false;
const int EMPTY = 0;
const int ITEM = 1;


struct P 
{
    int id;
    int x, y;
    int score;
    queue<string> messages;
};

int board_size;
int board[50][50];  
P players[2];


void* player_thread_function(void* arg) 
{
    P* player = (P*) arg;
    
    
    while (!flag) 
    {
        int move = rand() % 4;
        int new_x = player->x;
        int new_y = player->y;
        
          // Determine new position based on the move direction

        if (move == 0) 
        {
           if (player->x > 0)  { new_x--; }
        } 
        
        else if (move == 1) 
        {
            if (player->x < board_size - 1)  { new_x++; }
        } 
        
        else if (move == 2) 
        {
            if (player->y > 0)  { new_y--; }
        } 
        
        else if (move == 3) 
        {
            if (player->y < board_size - 1)  { new_y++; }
        }
        
             // Check if the new cell contains an item

        if (board[new_x][new_y] == ITEM) 
        {
            player->score++;
            board[new_x][new_y] = 'X';
            player->messages.push("Item found at (" + to_string(new_x) + ", " + to_string(new_y) + ")");
        }

         // Update player position
        player->x = new_x;
        player->y = new_y;

        player->messages.push("Moved to new Location (" + to_string(new_x) + ", " + to_string(new_y) + ")");
        
        sleep(1);
    }
    
    return nullptr;
}


void* input_thread_function(void* arg) 
{
    while (true) 
    {
        char input;
        cin >> input;
        if (input == 'z' || input == 'Z') 
        {
            flag = true;
            break;
        }
    }
    return nullptr;
}

void generate_board(int rnum) 
{
    int r = 10 + rand() % 90;
    
    cout<<endl<<"RANDOM NUMBER"<<r<<endl<<endl; 
    
    int last_digit = rnum % 10;
    int t = (r * last_digit) / rnum % 25;
    
    
    if (t < 10) {  board_size = t + 15; } 
    else { board_size = t; }


    for (int i = 0; i < board_size; i++) 
    {
        for (int j = 0; j < board_size; j++) 
        {
            board[i][j] = EMPTY;
        }
    }

 // Place items randomly on the board
    int items_count = board_size * board_size / 5;

    for (int i = 0; i < items_count; ++i) 
    {
        int x = rand() % board_size;
        int y = rand() % board_size;
        board[x][y] = ITEM;
    }
}

void display_board() 
{
    int c = (50 - board_size) / 2;

    cout << setw(c - 6) << "" << " ";
    for (int j = 0; j < board_size * 3 + 2; j++) 
    {   cout << "-";  }
    cout << endl;

    for (int i = 0; i < board_size; i++) 
    {
        cout << setw(c) << "" << "| ";

        for (int j = 0; j < board_size; j++) 
        {
           if (board[i][j] == ITEM)
                cout << "O ";
            else if (board[i][j] == 'X')
                cout << "X ";
            else
                cout << ". ";
        }
        
        cout << "|" << endl;
    }

    cout << setw(c - 6) << "" << " ";
    
    for (int j = 0; j < board_size * 3 + 2; j++) 
     {cout << "-";}
     cout << endl;
}

int main() 
{
    srand(time(0));

    int rnum = 591;
    generate_board(rnum);
    cout << "Game board size: " << board_size << "X" << board_size << endl;
    display_board();

  // Initialize player positions and scores
    players[0] = {1, 0, 0, 0};
    players[1] = {2, board_size - 1, board_size - 1, 0};

    pthread_t player_T[2], input_thread_id;
    
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE); // Set to joinable

   
    pthread_create(&player_T[0], &attr, player_thread_function, &players[0]);
    pthread_create(&player_T[1], &attr, player_thread_function, &players[1]);
    
    pthread_attr_destroy(&attr);

    pthread_create(&input_thread_id, nullptr, input_thread_function, nullptr);
    
    
    while (!flag) 
    {
        for (int i = 0; i < 2; i++) 
        {
            while (!players[i].messages.empty()) 
            {
                string message = players[i].messages.front();
                players[i].messages.pop();
                cout << "Player " << players[i].id << ": " << message << endl;
            }
        }

        display_board(); // Show updated board
        cout << "Player 1 Score: " << players[0].score << endl;
        cout << "Player 2 Score: " << players[1].score << endl;
 // Pause between updates
        sleep(1);
    }

 // Join threads before program exits
    pthread_join(player_T[0], nullptr);
    pthread_join(player_T[1], nullptr);
    pthread_join(input_thread_id, nullptr);

    cout << endl << endl;
    cout << "Game Over!" << endl;
    cout << "________________Final Scores________________" << endl << endl << endl;
    cout << "Player 1: " << players[0].score << endl;
    cout << "Player 2: " << players[1].score << endl;

    return 0;
}

