//  MUHAMMAD ABDULLAH BUTT
//  22I-0591
//  A#02

// p1.cpp

#include <iostream>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <cstring>
using namespace std;

struct Item 
{
    char name[20];
    int quantity;
    float price_per_item;
    float total_price;
};

float calculateSum(Item items[], int n) 
{
    float sum = 0;
    for (int i = 0; i < n; i++) 
    {
        items[i].total_price = items[i].quantity * items[i].price_per_item;
        sum += items[i].total_price;
    }
    return sum;
}

int main() 
{
    const char* pipe1 = "/tmp/pipe1";
    mkfifo(pipe1, 0666);  

    int num_items;
    cout << "Enter number of items: ";
    cin >> num_items;

    Item items[num_items];
    for (int i = 0; i < num_items; i++) 
    {
        cout << "Enter name of item " << i + 1 << ": ";
        cin >> items[i].name;
        cout << "Enter quantity: ";
        cin >> items[i].quantity;
        cout << "Enter price per item: ";
        cin >> items[i].price_per_item;
    }

    float sum = calculateSum(items, num_items);
    cout << "Process 1: Items Purchased = ";
    for (int i = 0; i < num_items; i++) {
        cout << items[i].name << " = " << items[i].total_price << endl;
    }
    cout << "Sum = " << sum << endl;

    int fd = open(pipe1, O_WRONLY);
    write(fd, &num_items, sizeof(num_items));
    write(fd, items, sizeof(Item) * num_items);
    write(fd, &sum, sizeof(sum));
    close(fd);

    return 0;
}

