//  MUHAMMAD ABDULLAH BUTT
//  22I-0591
//  A#02



#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <ctype.h>
using namespace std;

void reverse_Str(char *str) 
{
    int n = strlen(str);
    for (int i = 0; i < n / 2; i++) 
    {
        char temp = str[i];
        str[i] = str[n - i - 1];
        str[n - i - 1] = temp;
    }
}


void capitalize_Str(char *str) 
{
    for (int i = 0; str[i]; i++) 
    { str[i] = toupper(str[i]); }
}

int main() 
{
    int pipe1[2], pipe2[2], pipe3[2]; // 3 pipes
   // char message[100] = "noon refer";
    char message[100] = "unnamed pipes";
    char buffer[100];

    // Create pipes
    if (pipe(pipe1) == -1 || pipe(pipe2) == -1 || pipe(pipe3) == -1) 
    {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    pid_t pid1 = fork(); // Child1

    if (pid1 < 0) 
    {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid1 == 0) 
    { // Child1 process
        close(pipe1[0]); 
        write(pipe1[1], message, strlen(message) + 1); 
        close(pipe1[1]);

        close(pipe3[1]); 
        read(pipe3[0], buffer, sizeof(buffer));
        close(pipe3[0]);

        cout << "Child1 received capitalized message: " << buffer << endl;
        exit(0);
    }

    pid_t pid2 = fork(); 

    if (pid2 < 0) 
    {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid2 == 0) 
    { 
        close(pipe1[1]); 
        read(pipe1[0], buffer, sizeof(buffer)); 
        close(pipe1[0]);

        reverse_Str(buffer);

        close(pipe2[0]); 
        write(pipe2[1], buffer, strlen(buffer) + 1);

        read(pipe2[0], buffer, sizeof(buffer));
        close(pipe2[0]); 
        close(pipe2[1]); 
        capitalize_Str(buffer);

        close(pipe3[0]); 
        write(pipe3[1], buffer, strlen(buffer) + 1);
        close(pipe3[1]);
        exit(0);
    }

    pid_t pid3 = fork(); 

    if (pid3 < 0) 
    {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid3 == 0) 
    { 
        close(pipe2[1]); 
        read(pipe2[0], buffer, sizeof(buffer));
        close(pipe2[0]); 

        cout << "Child3 received reversed message: " << buffer << endl;

        close(pipe2[0]);
        write(pipe2[1], buffer, strlen(buffer) + 1);
        close(pipe2[1]); 
        exit(0);
    }

    
    for (int i = 0; i < 3; i++) 
    { wait(NULL); }

    return 0;
}
