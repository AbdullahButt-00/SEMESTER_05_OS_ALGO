//  MUHAMMAD ABDULLAH BUTT
//  22I-0591
//  A#02

// p2.cpp
#include <iostream>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <cstring>
using namespace std;

struct Item 
{
    char name[20];
    int quantity;
    float price_per_item;
    float total_price;
};

float calculateTax(float sum) 
{
    return sum * 0.08;
}

int main() 
{
    const char* pipe1 = "/tmp/pipe1";
    const char* pipe2 = "/tmp/pipe2";
    mkfifo(pipe2, 0666);

    int num_items;
    Item items[100];  
    float sum;

   
    int fd1 = open(pipe1, O_RDONLY);
    read(fd1, &num_items, sizeof(num_items));
    read(fd1, items, sizeof(Item) * num_items);
    read(fd1, &sum, sizeof(sum));
    close(fd1);

    float tax = calculateTax(sum);
    float taxed_sum = sum + tax;

    cout << "Process 2: 8 % Tax = " << tax << ", Taxed Sum = " << taxed_sum << endl;
    
    int fd2 = open(pipe2, O_WRONLY);
    write(fd2, &num_items, sizeof(num_items));
    write(fd2, items, sizeof(Item) * num_items);
    write(fd2, &sum, sizeof(sum));
    write(fd2, &taxed_sum, sizeof(taxed_sum));
    close(fd2);

    return 0;
}

