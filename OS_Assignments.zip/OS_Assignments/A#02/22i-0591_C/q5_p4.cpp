//  MUHAMMAD ABDULLAH BUTT
//  22I-0591
//  A#02

// p4.cpp
#include <iostream>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <cstring>
#include <iomanip>
#include <algorithm>
using namespace std;

struct Item 
{
    char name[20];
    int quantity;
    float price_per_item;
    float total_price;
};

void sortItemsByPrice(Item items[], int n) 
{
    for (int i = 0; i < n - 1; i++) 
    {
        for (int j = 0; j < n - 1 - i; j++) 
        {
            if (items[j].total_price < items[j + 1].total_price) {  swap(items[j], items[j + 1]);  }
        }
    }
}

void displayReceipt(Item items[], int n, float sum, float taxed_sum, float final_sum) 
{
    cout << "\nReceipt:\n";
    cout << left << setw(15) << "Items" << "Price" << endl;
    for (int i = 0; i < n; i++) {
        cout << left << setw(15) << items[i].name << items[i].total_price << endl;
    }
    cout << "Total: " << sum << endl;  
    cout << "After 8% tax: " << taxed_sum << endl;  
    cout << "After 10% sale: " << final_sum << endl;  
}

int main() 
{
    const char* pipe3 = "/tmp/pipe3";

    int num_items;
    Item items[100];
    float sum, taxed_sum, final_sum;
    
    int fd3 = open(pipe3, O_RDONLY);
    read(fd3, &num_items, sizeof(num_items));
    read(fd3, items, sizeof(Item) * num_items);
    read(fd3, &sum, sizeof(sum));
    read(fd3, &taxed_sum, sizeof(taxed_sum));
    read(fd3, &final_sum, sizeof(final_sum));
    close(fd3);

    sortItemsByPrice(items, num_items);
    displayReceipt(items, num_items, sum, taxed_sum, final_sum);

    return 0;
}

