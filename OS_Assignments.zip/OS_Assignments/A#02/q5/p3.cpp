// process3.cpp
#include <iostream>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <cstring>
using namespace std;

struct Item 
{
    char name[20];
    int quantity;
    float price_per_item;
    float total_price;
};

float applyDiscount(float sum) 
{
    if (sum > 250) return sum * 0.1; 
    return 0;
}

int main() 
{
    const char* pipe2 = "/tmp/pipe2";
    const char* pipe3 = "/tmp/pipe3";
    mkfifo(pipe3, 0666);

    int num_items;
    Item items[100];
    float sum, taxed_sum;

   
    int fd2 = open(pipe2, O_RDONLY);
    read(fd2, &num_items, sizeof(num_items));
    read(fd2, items, sizeof(Item) * num_items);
    read(fd2, &sum, sizeof(sum));  
    read(fd2, &taxed_sum, sizeof(taxed_sum));  
    close(fd2);

    float discount = applyDiscount(sum);
    float final_sum = sum - discount;

    cout << "Process 3: 10% sale = " << discount << ", Final  = " << final_sum << endl;

    int fd3 = open(pipe3, O_WRONLY);
    write(fd3, &num_items, sizeof(num_items));
    write(fd3, items, sizeof(Item) * num_items);
    write(fd3, &sum, sizeof(sum));
    write(fd3, &taxed_sum, sizeof(taxed_sum));
    write(fd3, &final_sum, sizeof(final_sum));  // Correct final sum after discount applied to original sum
    close(fd3);

    return 0;
}

