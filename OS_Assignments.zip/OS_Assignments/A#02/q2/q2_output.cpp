//  MUHAMMAD ABDULLAH BUTT
//  22I-0591
//  A#02


#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>

using namespace std;


void Grade(int t, int obt, int subNum) 
{
    float percentage = (static_cast<float>(obt) / t) * 100; 
    cout << "Subject " << subNum << " - Percentage: " << percentage << "%" << endl;

    if (percentage >= 80)
        cout << "Grade: A" << endl;
    else if (percentage >= 70)
        cout << "Grade: B" << endl;
    else if (percentage >= 60)
        cout << "Grade: C" << endl;
    else if (percentage >= 50)
        cout << "Grade: D" << endl;
    else
        cout << "Grade: F" << endl;
}

int main() 
{
  
    const char* fifo = "pipe1";
    int total, obtained;

    for (int i = 0; i < 5; ++i) 
    {
        int fd = open(fifo, O_RDONLY);
        if (fd < 0) 
        {
            perror("Failed to open pipe");
            return 1;
        }

        
        read(fd, &total, sizeof(total));       
        read(fd, &obtained, sizeof(obtained)); 
        close(fd);

        Grade(total, obtained, i + 1);
    }

    return 0;
}
