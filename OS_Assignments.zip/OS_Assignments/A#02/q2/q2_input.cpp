//  MUHAMMAD ABDULLAH BUTT
//  22I-0591
//  A#02



#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <cstring>
#include <cstdlib>

using namespace std;

int main() {
    
    int total, obtained;
    
    const char* fifo = "pipe1";
    mkfifo(fifo, 0666);  
    
    
    for (int i = 0; i < 5; ++i) 
    {
        cout << "Subject " << i + 1 << " - Total: ";
        cin >> total;
        cout << "Subject " << i + 1 << " - Obtained: ";
        cin >> obtained;

        int fd = open(fifo, O_WRONLY);
        if (fd < 0) 
        {
            perror("Failed to open pipe");
            return 1;
        }

        write(fd, &total, sizeof(total));      
        write(fd, &obtained, sizeof(obtained)); 
        close(fd);
    }

    return 0;
}
