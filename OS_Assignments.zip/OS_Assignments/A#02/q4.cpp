//  MUHAMMAD ABDULLAH BUTT
//  22I-0591
//  A#02



#include <iostream>
#include <unistd.h>
#include <cstring>
#include <sys/wait.h>

using namespace std;

void process_P1(int writePipe[], int readPipe[]) 
{
    close(writePipe[0]); 
    close(readPipe[1]);   

    char ch;
    int sent_N =1;

    cout << "Enter characters : " << endl;
    while (true) 
    {
     cin >> ch;
     write(writePipe[1], &ch, 1); 
        if (ch == '#' || ch == '.' || ch == '?') 
        {
          if (ch == '#') { break; }
        read(readPipe[0], &sent_N, sizeof(sent_N));
        
        cout << "Sentence NO#: " <<sent_N<< " received by P1" << endl;
        }
    }

    close(writePipe[1]); 
    close(readPipe[0]); 
    cout << "P1 exitinggg..." << endl;
}

void process_P2(int writePipe[], int readPipe[]) 
{
    close(writePipe[0]); 
    close(readPipe[1]);  

    char ch;
    string s = "";
    int sent_N = 1;

    while (true) 
    {
        read(readPipe[0], &ch, 1);  

        if (ch == '#') 
        { cout << "Incomplete sentence received" << endl; break; }
        s += ch;

        if (ch == '.' || ch == '?') { cout << "Sentence Received: " << s << endl;

            write(writePipe[1], &sent_N, sizeof(sent_N));
            cout << "Sentence number sent to P1" << endl;

            sent_N++;
            s = "";  
        }
    }

    close(writePipe[1]);  
    close(readPipe[0]);   
    cout << "P2 exitingg..." << endl;
}

int main() 

{
    int p1_P2[2], p2_P1[2];

    // Create pipes
    if (pipe(p1_P2) == -1 || pipe(p2_P1) == -1) 
    {
        cout << "Pipe creation failed!" << endl;
        return 1;
    }

    pid_t pid = fork();

    if (pid < 0) 
    {
        cout << "Fork failed!" << endl;
        return 1;
    }

    if (pid == 0) 
    {
        // (P2)
        process_P2(p2_P1, p1_P2);
    }
     
    else 
    {  // (P1)
        process_P1(p1_P2, p2_P1);
        wait(NULL);
    }

    return 0;
}

