//  MUHAMMAD ABDULLAH BUTT
//  22I-0591
//  A#02

#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <cstring>


using namespace std;

int main(int argc, char *argv[]) 
{
    if (argc != 3) 
    {
        cout << "Usage: " << argv[0] << "./w ./r" << endl;
        return 1;
    }

    int pipefds[2];
    if (pipe(pipefds) == -1) 
    {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

 
    pid_t pid1 = fork();
    if (pid1 < 0) 
    {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid1 == 0) 
    {
        // C1 process
        
        close(pipefds[0]);
        dup2(pipefds[1], STDOUT_FILENO);
        
        
        execl(argv[1], argv[1], (char *)NULL);
        perror("execl");  
        exit(EXIT_FAILURE);
    }

    // C2 process 
    pid_t pid2 = fork();
    if (pid2 < 0) 
    {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid2 == 0) 
    {  // C2 process 
        
        close(pipefds[1]);
        dup2(pipefds[0], STDIN_FILENO);
        
        
        execl(argv[2], argv[2], (char *)NULL);
        perror("execl");  
        exit(EXIT_FAILURE);
    }

    
    close(pipefds[0]);
    close(pipefds[1]);

    // Wait for c1 & c2 to finish
    waitpid(pid1, NULL, 0);
    waitpid(pid2, NULL, 0);

    return 0;
}
