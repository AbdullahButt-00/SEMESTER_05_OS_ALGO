//  MUHAMMAD ABDULLAH BUTT
//  22I-0591
//  A#02



#include <iostream>
#include <unistd.h>
#include <cstring>

using namespace std;

int main() {
    const char* input = "OS is very easy _____ problem01 solvd";
    write(STDOUT_FILENO, input, strlen(input));  
    return 0;
}
