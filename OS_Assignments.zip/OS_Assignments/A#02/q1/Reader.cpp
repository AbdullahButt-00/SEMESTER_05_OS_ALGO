//  MUHAMMAD ABDULLAH BUTT
//  22I-0591
//  A#02


#include <iostream>
#include <unistd.h>

using namespace std;

int main() {
    char buf[100];
    int bytesRead = read(STDIN_FILENO, buf, sizeof(buf));
    
    if (bytesRead > 0) 
    {
        buf[bytesRead] = '\0';  
        cout << "Reader Received Message: " << buf << endl;
    }
    return 0;
}
