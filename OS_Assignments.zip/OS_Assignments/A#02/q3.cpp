//  MUHAMMAD ABDULLAH BUTT
//  22I-0591
//  A#02



#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <ctype.h>
using namespace std;

void reverse_Str(char *str) 
{
    int n = strlen(str);
    for (int i = 0; i < n / 2; i++) 
    {
        char temp = str[i];
        str[i] = str[n - i - 1];
        str[n - i - 1] = temp;
    }
}


void capitalize_Str(char *str) 
{
    for (int i = 0; str[i]; i++) 
    { str[i] = toupper(str[i]); }
}

int main() 
{
    int pipe1[2], pipe2[2], pipe3[2]; // 3 pipes
   // char message[100] = "noon refer";
    char message[100] = "unnamed pipes";
    char buffer[100];

    // Create pipes
    if (pipe(pipe1) == -1 || pipe(pipe2) == -1 || pipe(pipe3) == -1) 
    {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    pid_t pid1 = fork(); // Child1

    if (pid1 < 0) 
    {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid1 == 0) 
    { // Child1 process
        close(pipe1[0]); // Close read end of pipe1 (sending to Child2)
        write(pipe1[1], message, strlen(message) + 1); // Send message to Child2
        close(pipe1[1]); // Close write end of pipe1

        // Read from Child2 (capitalized message)
        close(pipe3[1]); // Close write end of pipe3 (from Child2)
        read(pipe3[0], buffer, sizeof(buffer));
        close(pipe3[0]);

        cout << "Child1 received capitalized message: " << buffer << endl;
        exit(0);
    }

    pid_t pid2 = fork(); // Child2

    if (pid2 < 0) 
    {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid2 == 0) 
    { // Child2 process
        // Read from Child1
        close(pipe1[1]); // Close write end of pipe1
        read(pipe1[0], buffer, sizeof(buffer)); // Read from pipe1 (message from Child1)
        close(pipe1[0]);

        reverse_Str(buffer);

        // Send reversed message to Child3
        close(pipe2[0]); // Close read end of pipe2 (sending to Child3)
        write(pipe2[1], buffer, strlen(buffer) + 1);

        // Read reversed message back from Child3
        read(pipe2[0], buffer, sizeof(buffer));
        close(pipe2[0]); // Close read end after reading from Child3
        close(pipe2[1]); // Close write end of pipe2 after full use

        capitalize_Str(buffer);

        // Send capitalized message to Child1
        close(pipe3[0]); // Close read end of pipe3 (sending to Child1)
        write(pipe3[1], buffer, strlen(buffer) + 1);
        close(pipe3[1]); // Close write end of pipe3
        exit(0);
    }

    pid_t pid3 = fork(); // Child3

    if (pid3 < 0) 
    {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid3 == 0) 
    { // Child3 process
        // Read reversed message from Child2
        close(pipe2[1]); // Close write end of pipe2
        read(pipe2[0], buffer, sizeof(buffer));
        close(pipe2[0]); // Close read end after reading

        cout << "Child3 received reversed message: " << buffer << endl;

        // Send reversed message back to Child2
        close(pipe2[0]); // Close read end of pipe2 (sending to Child2)
        write(pipe2[1], buffer, strlen(buffer) + 1);
        close(pipe2[1]); // Close write end of pipe2
        exit(0);
    }

    
    for (int i = 0; i < 3; i++) 
    { wait(NULL); }

    return 0;
}
