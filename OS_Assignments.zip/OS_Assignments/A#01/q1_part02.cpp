#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
using namespace std;
#include <vector>

struct Node 
{
    char letter;
    pid_t pid;
    pid_t ppid;
    int ascii;
   vector<Node*> children;
};


void displayNodeInfo(Node* node) 
{
   cout << "PPID: " << node->ppid << ", PID: " << node->pid << ", Letter: " << node->letter << ", ASCII: " << node->ascii << endl;
}


void createProcessTree(Node* parent, std::vector<char>& letters, int index) 
{
 if (index >= letters.size()) 
 return;
 
 pid_t pid = fork();
 
 if (pid < 0) 
 
 { cout << "Fork failed!" << endl; exit(1); } 
 
 else if (pid == 0) 
   {        
	 Node* child = new Node{letters[index], getpid(), getppid(), int(letters[index])};
	 parent->children.push_back(child);
	 createProcessTree(child, letters, index + 1);

  displayNodeInfo(child);
  exit(0); 
    
    } 
    
 else { wait(NULL); }
}


int main() 
{
    vector<char> name = {'A', 'B', 'D', 'U', 'L', 'L', 'A', 'H', 'B', 'U', 'T', 'T'};
    Node* root = new Node{'A', getpid(), 0, int('A')};
    createProcessTree(root, name, 1);
    displayNodeInfo(root);

    return 0;
}

