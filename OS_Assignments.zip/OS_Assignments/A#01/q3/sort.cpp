#include <iostream>
#include <cstring>
using namespace std;

int main(int argc, char* argv[]) 
{
    if (argc != 2) 
    {
        cout << "Usage: sort <string>" << endl;
        return 1;
    }
    
    char* str = argv[1];
    int l = strlen(str);


 for (int i = 0; i < l-1; i++) 
 {
        for (int j = 0; j < l-i-1; j++) 
        {
            if (str[j] > str[j+1]) 
            {
                char t = str[j];
                str[j] = str[j + 1];
                str[j + 1] = t;
            }
        }
    }

    cout << "Sorted string: " << str << endl;
    
    return 0;
}

