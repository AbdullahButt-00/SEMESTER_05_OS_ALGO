#include <iostream>
using namespace std;

int main(int argc, char* argv[]) 
{
    if (argc != 2) 
    {
        cout << "Usage: add2ascii <string>" << endl;
        return 1;
    }

    char* str = argv[1];

    for (int i = 0; str[i] != '\0'; i++) 
    {
        str[i] += 2;  
    }

    cout << "String after adding 2 to ASCII values: " << str << endl;

    return 0;
}

