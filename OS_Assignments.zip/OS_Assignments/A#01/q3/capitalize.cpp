#include <iostream>
#include <cctype>
using namespace std;

int main(int argc, char* argv[]) 
{
    if (argc != 2) 
    {
        cout << "Usage: capitalize <string>" << endl;
        return 1;
    }

  
 string str = argv[1];

 for (int i = 0; str[i]!='\0';i++) 
    {
      
      if (str[i] >= 'a' && str[i] <= 'z')         { str[i] = str[i] - 'a' + 'A';  }
        
    }

    cout << "Capitalized string: " << str << endl;
    return 0;
}

