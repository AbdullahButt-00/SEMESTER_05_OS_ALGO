#include <iostream>
#include <cstring>
using namespace std;

int main(int argc, char* argv[]) 
{
    if (argc != 2) 
    {
        cout << "Usage: reverse <string>" << endl;
        return 1;
    }

  
    char* str = argv[1];
    int l = strlen(str);

    for (int i = 0; i < l / 2; i++) 
    {
        char temp = str[i];
        str[i] = str[l-i-1];
        str[l-i-1] = temp;
    }

  
    cout << "Reversed string: " << str << endl;

    return 0;
}



