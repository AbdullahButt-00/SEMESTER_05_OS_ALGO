#include <iostream>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <cstring>
using namespace std;

int main() 
{

string s;
cout << "Enter a string: ";
getline(cin, s);

pid_t pid1 = fork();

    if (pid1 == 0) 
    {
        // c1
        char* args[] = { (char*) "./reverse", (char*) s.c_str(), NULL };
        execv(args[0], args); 
    } 
    
    else if (pid1 > 0) 
    {
        wait(NULL); // Wait c1

        pid_t pid2 = fork();
        
        if (pid2 == 0) 
        {
            // c2
            char* args[] = { (char*) "./length", (char*) s.c_str(), NULL };
            execv(args[0], args); 
        } 
        
        else if (pid2 > 0) 
        {
            wait(NULL); //Wait c2

            pid_t pid3 = fork();
            
            if (pid3 == 0) 
            {
                // c3
                char* args[] = { (char*) "./ascii2", (char*) s.c_str(), NULL };
                execv(args[0], args); 
            } 
            
            else if (pid3 > 0) 
            {
                wait(NULL); //Wait c3

                pid_t pid4 = fork();
                
                if (pid4 == 0) 
                {
                    // c4
                    char* args[] = { (char*) "./sort", (char*) s.c_str(), NULL };
                    execv(args[0], args);
                } 
                
                else if (pid4 > 0) 
                {
                    wait(NULL); // Wait c4

                    pid_t pid5 = fork();
                    
                    if (pid5 == 0) 
                    {
                        //c5
                        char* args[] = { (char*) "./capitalize", (char*) s.c_str(), NULL };
                        execv(args[0], args);
                    } 
                    else if (pid5 > 0) {
                        wait(NULL); // Wait c5
                    }
                }
            }
        }
    } 
    
    
    else 
    {
        cout << "Fork failed! ERROR" << endl;
    }

    return 0;
}

