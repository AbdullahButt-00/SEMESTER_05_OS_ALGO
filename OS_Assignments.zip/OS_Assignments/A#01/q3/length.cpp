#include <iostream>
#include <cstring>
using namespace std;

int main(int argc, char* argv[]) 
{
    if (argc != 2) 
    {
        cout << "Usage: length <string>" << endl;
        return 1;
    }

    string s = argv[1];
    cout << "Length of the string: " << s.length() << endl;

    return 0;
}

