#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <cstdlib>
using namespace std;


int main() 
{

pid_t p = fork();  

if (p == -1) 
{
  perror("fork");
   return 1;
}


if (p == 0) 
{
      
  execlp("sh", "sh", "-c", "ls ~ > output1.txt", (char *)NULL);
  perror("execlp");   return 1;
} 


else 
{

 wait(NULL);  
 const char* h_Path = getenv("HOME");
  if (h_Path == nullptr) 
  {
      cout << "Error! HOME env var not set." << endl; return 1;
  }

  string new_Path = string(h_Path) + ":" + getenv("PATH");
  setenv("PATH", new_Path.c_str(), 1);
  string grep_Cd = "grep -r 'output1.txt' " + string(h_Path) + "/*.txt";
  execlp("sh", "sh", "-c", grep_Cd.c_str(), (char *)NULL);

    perror("execlp");          
    return 1;
}

    return 0;
}


